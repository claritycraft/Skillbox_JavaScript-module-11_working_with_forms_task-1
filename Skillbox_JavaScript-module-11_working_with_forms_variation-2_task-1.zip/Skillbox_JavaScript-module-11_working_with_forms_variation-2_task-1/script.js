const inputName = document.querySelector("#name");
const inputEmail = document.querySelector("#mail");
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const ulEl = document.querySelector("#list-item");
const buttonEl = document.querySelector(".button-add");

const validateName = () => {
  const name = inputName.value.trim();

  console.log("Введённое имя:", name);

  if (name === "") {
    inputName.setCustomValidity("Заполните это поле");

    inputName.reportValidity();

    console.log("Валидация не пройдена — возвращаем false");

    return false;
  } else {
    inputName.setCustomValidity("");
    console.log("Валидация пройдена — возвращаем true");
    return true;
  }
};

const validateEmail = () => {
  const email = inputEmail.value.trim();

  if (email === "") {
    inputEmail.setCustomValidity("Заполните email");

    inputEmail.reportValidity();

    console.log("Ошибка: email не введён");

    return false;
  } else if (!emailRegex.test(email)) {
    inputEmail.setCustomValidity("Неверный формат email");

    inputEmail.reportValidity();
    console.log("Ошибка: email не соответствует формату");

    return false;
  } else {
    inputEmail.setCustomValidity("");
    console.log("Email валиден");

    return true;
  }
};

buttonEl.addEventListener("click", function (e) {
  console.log("Нажата кнопка — запускаем validateName");

  console.log("Нажата кнопка — запускаем validateEmail");

  e.preventDefault();

  const isNameValid = validateName();

  console.log("Результат валидации:", isNameValid);

  const isEmailValid = validateEmail();

  if (isNameValid && isEmailValid) {
    const nameUser = inputName.value.trim();

    const emailUser = inputEmail.value.trim();

    const genderInput = document.querySelector('input[name="gender"]:checked');

    const genderUser = genderInput ? genderInput.value : "Не указан";

    const ratingUser = document.querySelector("#raiting")?.value;
    const checkedBoxes = document.querySelectorAll(
      'input[name="hobby"]:checked'
    );

    const interestsUser =
      [...checkedBoxes].map((checkbox) => checkbox.value).join(", ") ||
      "Не выбрано";
    console.log(interestsUser);

    const commentUser = "комментарии";

    ulEl.innerHTML = `
  <li class="item-element">Имя пользователя: <span class="span-list">${nameUser}</span></li>
  <li class="item-element">Email: <span>${emailUser}</span></li>
  <li class="item-element">Пол: <span>${genderUser}</span></li>
  <li class="item-element">Оценка сервиса: <span>${ratingUser}</span></li>
  <li class="item-element">Интересы пользователя: <span>${interestsUser}</span></li>
  <li class="item-element">Дополнительные комментарии: <span>${commentUser}</span></li>
`;
  }
});
