document.getElementById("rating").oninput = function () {
  document.getElementById("ratingValue").innerText = this.value;
};

document.getElementById("surveyForm").onsubmit = function (event) {
  event.preventDefault();

  let name = document.getElementById("username").value.trim();
  let email = document.getElementById("email").value.trim();
  let gender = document.querySelector("input[name='gender']:checked");
  let rating = document.getElementById("rating").value;
  let interests = Array.from(
    document.querySelectorAll("input[type='checkbox']:checked")
  ).map((checkbox) => checkbox.value);
  let comments = document.getElementById("comments").value.trim();

  let nameError = document.getElementById("nameError");
  let emailError = document.getElementById("emailError");
  nameError.innerText = "";
  emailError.innerText = "";

  let isValid = true;
  if (!name) {
    nameError.innerText = "Введите имя";
    isValid = false;
  }

  let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!email.match(emailPattern)) {
    emailError.innerText = "Введите корректный email";
    isValid = false;
  }

  if (isValid) {
    document.getElementById("result").innerHTML = `
        <p><strong>Имя:</strong> ${name}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Пол:</strong> ${gender ? gender.value : "Не указан"}</p>
        <p><strong>Оценка сервиса:</strong> ${rating}</p>
        <p><strong>Интересы:</strong> ${
          interests.length > 0 ? interests.join(", ") : "Не указаны"
        }</p>
        <p><strong>Комментарии:</strong> ${comments || "Нет"}</p>
    `;
  }
};
